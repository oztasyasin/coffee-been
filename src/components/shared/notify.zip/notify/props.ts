export interface NotificationBarProps {

}